/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto;
//Librerias
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Proyecto {
    
     DefaultTableModel modelo;

   public DefaultTableModel InicialializarTabla()    
    {
        modelo =new DefaultTableModel();
        
        //Agregar la columnas de la tabla al modelo
        modelo.addColumn("Producto");
        modelo.addColumn("Precio Unidad");
        modelo.addColumn("Cantidad");
        
        return modelo;
    }
    
    public void AgregarProducto(DefaultTableModel modelo, String[] producto)
    {
        //Agregar los datos obtenidos a la tabla 
        modelo.addRow(producto);
    }
    
    public void MesajeDespedida()
    {
        JOptionPane.showMessageDialog(null, "Gracias por utilizar el programa.");
    }
}
